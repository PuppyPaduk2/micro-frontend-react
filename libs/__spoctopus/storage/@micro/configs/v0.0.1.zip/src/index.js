const routes = require("./routes");
const services = require("./services");

module.exports = { routes, services };
